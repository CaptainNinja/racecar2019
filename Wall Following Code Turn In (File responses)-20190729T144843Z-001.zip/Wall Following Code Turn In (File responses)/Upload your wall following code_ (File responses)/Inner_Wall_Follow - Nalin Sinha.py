#!/usr/bin/env python
import numpy as np
import rospy
from sklearn.linear_model import LinearRegression

from rospy.numpy_msg import numpy_msg
from sensor_msgs.msg import LaserScan
from ackermann_msgs.msg import AckermannDriveStamped
class WallFollower:
    # Import ROS parameters from the "params.yaml" file.
    # Access these variables in class functions with self:
    # i.e. self.CONSTANT
    SCAN_TOPIC = rospy.get_param("wall_follower/scan_topic")
    DRIVE_TOPIC = rospy.get_param("wall_follower/drive_topic")
    SIDE = rospy.get_param("wall_follower/side")
    VELOCITY = rospy.get_param("wall_follower/velocity")
    DESIRED_DISTANCE = rospy.get_param("wall_follower/desired_distance")
    isTurning = False
    turnStart = 0
    def __init__(self):
        # Initialize your publishers and
        # subscribers
        self.data = None    
        self.angle = 0
        self.cmd = AckermannDriveStamped()
        self.laser_sub = rospy.Subscriber(self.SCAN_TOPIC, LaserScan, self.scan, queue_size=1)
        self.drive_pub = rospy.Publisher(self.DRIVE_TOPIC, AckermannDriveStamped, queue_size=1)
        self.cmd.drive.speed = 0.5
    def scan(self, data):
        #stores the lidar data so you can work with it
        self.data = data
        f = open("laserscanData.txt", "a")
        #print(self.data)
        #calls function that controls driving
        self.drive()
    
    def drive(self):
        """controls driving"""
        #gets the angle required
        self.angle = self.find_wall()
        #print("Driving")
        #sets speed and driving angle 

        self.cmd.drive.speed = 0.5
        self.cmd.drive.steering_angle = self.angle
    
        if self.findFrontWall():
            self.cmd.drive.steering_angle = 1

        #publishes the command
        self.drive_pub.publish(self.cmd)
    def find_wall(self):
        # if lidar data has not been received, do nothing
        if self.data == None:
            return 0
        ## TO DO: Find Alg for Wall Following ##
        #return 0
        #actual = lidar[17]
        actual = np.median(self.data.ranges[14:21])
        

        
        PROPORTIONAL_CONSTANT = 0.2
        EXPECTED = 1
        IDEAL_SPEED = 0.5
        lidar = self.data.ranges
        error = EXPECTED-actual
        if abs(error)<.2:
            error = 0
        omega = PROPORTIONAL_CONSTANT/IDEAL_SPEED*error
        """
        if(omega>500):
            omega = 1500
        else:
            omega = -1500
       
        omega/=1500
         """   
        return omega
        
    def findFrontWall(self):
        distance = self.data.ranges[50]
        print(distance)
        if distance<3.5:
            #turnStart = time.time()
            return True
        return False
    """    
    def findgap(self):
        lidar = list(self.data.range)[60:83][::-1]
        x = [i * 2.7 for i,item in enumerate(lidar[::-1])][::-1]
        model = LinearRegression().fit(np.array(x),np.array(lidar))
        return model.coef_ < 0
        
        
    def turn(self):
        if time.time() - turnStart >= 1 :
            self.cmd.drive.steering_angle = 0
    """
            
            
        
        

    """Lidar data is now stored in self.data, which can be accessed
    using self.data.ranges (in simulation, returns an array).
    Lidar data at an index is the distance to the nearest detected object
    self.data.ranges[0] gives the leftmost lidar point
    self.data.ranges[100] gives the rightmost lidar point
    self.data.ranges[50] gives the forward lidar point
    """
    #returns the output of your alg, the new angle to drive in
    #return tempAngle
if __name__ == "__main__":
    rospy.init_node('wall_follower')
    wall_follower = WallFollower()
    rospy.spin()

