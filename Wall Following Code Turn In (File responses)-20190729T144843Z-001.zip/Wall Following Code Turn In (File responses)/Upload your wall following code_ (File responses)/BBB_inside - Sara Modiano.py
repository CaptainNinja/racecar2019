#!/usr/bin/env python
import numpy as np
import rospy
from rospy.numpy_msg import numpy_msg
from sensor_msgs.msg import LaserScan
from ackermann_msgs.msg import AckermannDriveStamped
class WallFollower:
   # Import ROS parameters from the "params.yaml" file.
   # Access these variables in class functions with self:
   # i.e. self.CONSTANT
   SCAN_TOPIC = rospy.get_param("wall_follower/scan_topic")
   DRIVE_TOPIC = rospy.get_param("wall_follower/drive_topic")
   SIDE = rospy.get_param("wall_follower/side")
   VELOCITY = rospy.get_param("wall_follower/velocity")
   DESIRED_DISTANCE = rospy.get_param("wall_follower/desired_distance")
   def __init__(self):
       # Initialize your publishers and
       # subscribers
       self.data = None
       self.angle = 0
       self.cmd = AckermannDriveStamped()
       self.laser_sub = rospy.Subscriber(self.SCAN_TOPIC, LaserScan, self.scan, queue_size=1)
       self.drive_pub = rospy.Publisher(self.DRIVE_TOPIC, AckermannDriveStamped, queue_size=1)
   def scan(self, data):
   #stores the lidar data so you can work with it
       self.data = data
   #calls function that controls driving
       self.drive()

   def drive(self):
       """controls driving"""
       #Algorithm for driving
   #gets the angle required
       self.angle = self.find_wall()
   #sets speed and driving angle
       self.cmd.drive.speed = self.VELOCITY
       self.cmd.drive.steering_angle = self.angle
       #publishes the command
       self.drive_pub.publish(self.cmd)
   def find_wall(self):
       tempAngle = 0
   # if lidar data has not been received, do nothing
       if self.data == None:
           return 0
   ## TO DO: Find Alg for Wall Following ##
       """Lidar data is now stored in self.data, which can be accessed
       using self.data.ranges (in simulation, returns an array).
       Lidar data at an index is the distance to the nearest detected object
       self.data.ranges[0] gives the leftmost lidar point
       self.data.ranges[100] gives the rightmost lidar point
       self.data.ranges[50] gives the forward lidar point
       """

       values = self.data.ranges
       scanners = len(values)

       leftPoints = self.data.ranges[(scanners/3*2):scanners]
       rightPoints = values[0:scanners/3]
       midPoints = values[scanners/3:(scanners/3*2)]

       MR = min(rightPoints)
       ML = min(leftPoints)
       MM = min(midPoints)
       mins = [MR, ML, MM]

       if rospy.get_param("wall_follower/side") == -1:
        for distance in mins:
         if 0<distance<1:
          tempAngle += 6
         if 1<distance<1.5:
          tempAngle += 4
         if 1.5<distance<2:
          tempAngle += 2
         if 2<distance<2.5:
          tempAngle -= 2
         if 2.5<distance<3:
          tempAngle -= 4
         if 3<distance:
          tempAngle -= 6
         if 1.9<distance<2.1:
          tempAngle = 0

       if rospy.get_param("wall_follower/side") == 1:
        for distance in mins:
         if 0<distance<1:
          tempAngle -= 6
         if 1<distance<1.5:
          tempAngle -= 4
         if 1.5<distance<2:
          tempAngle -= 2
         if 2<distance<2.5:
          tempAngle += 2
         if 2.5<distance<3:
          tempAngle += 4
         if 3<distance:
          tempAngle += 6
         if 1.9<distance<2.1:
          tempAngle = 0

        '''if rospy.get_param("wall_follower/type") == "outside":
        tempAngle = 0
        minDistance = min(values)
        perpDistance = values[(scanners)/6]
        change = abs((values.index(perpDistance) - values.index(minDistance))*(270/scanners))
        #if minDistance > perpDistance:
        tempAngle += change
        #if minDistance < perpDistance:
         #tempAngle -= change'''

          


        '''if 1.5<min(rightPoints)<2:
          tempAngle +=2
        if 1<min(rightPoints)<1.5:
          tempAngle += 4
        if 0<min(rightPoints)<1:
          tempAngle += 6
        if 2.5>min(rightPoints)>2:
          tempAngle -= 2
        if 3>min(rightPoints)>2.5:
          tempAngle -= 4
        if min(rightPoints)>3:
          tempAngle -= 6
        if 1.9<min(rightPoints)<2.1:
          tempAngle = 0

        if 1.5<min(midPoints)<2:
          tempAngle +=2
        if 1<min(midPoints)<1.5:
          tempAngle += 4
        if 0<min(midPoints)<1:
          tempAngle += 6
        if 2.5>min(midPoints)>2:
          tempAngle -= 2
        if 3>min(midPoints)>2.5:
          tempAngle -= 4
        if min(midPoints)>3:
          tempAngle -= 6
        if 1.9<min(midPoints)<2.1:
          tempAngle = 0

        if 1.5<min(leftPoints)<2:
          tempAngle +=2
        if 1<min(leftPoints)<1.5:
          tempAngle += 4
        if 0<min(leftPoints)<1:
          tempAngle += 6
        if 2.5>min(leftPoints)>2:
          tempAngle -= 2
        if 3>min(leftPoints)>2.5:
          tempAngle -= 4
        if min(leftPoints)>3:
          tempAngle -= 6
        if 1.9<min(leftPoints)<2.1:
          tempAngle = 0'''


   #returns the output of your alg, the new angle to drive in
       return tempAngle



if __name__ == "__main__":
   rospy.init_node('wall_follower')
   wall_follower = WallFollower()
   rospy.spin()