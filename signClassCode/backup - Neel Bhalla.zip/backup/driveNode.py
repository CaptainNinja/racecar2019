#!/usr/bin/env python

#import libraries and color segmentation code
from turnRectRos import *
import rospy
import cv2
import time
import numpy as np
from newZed import Zed_converter
from math import pi
import os
#from cv_bridge import CvBridge, CvBridgeError
from color_segmentation import cd_color_segmentation
from ackermann_msgs.msg import AckermannDriveStamped
from sensor_msgs.msg import LaserScan, Joy, Image
import time
import potentialFields as pF
#initalize global variables

AUTONOMOUS_MODE = True

#What should your drive topic be?
DRIVE_TOPIC = '/drive'
SCAN_TOPIC = '/scan'

class driveStop(object):
	"""class that will help the robot drive and stop at certain conditions
	"""
	def __init__(self):
		"""initalize the node"""
		rospy.init_node("driveStop")
		self.pub = rospy.Publisher(DRIVE_TOPIC, AckermannDriveStamped, queue_size = 1)
		rospy.Subscriber("/scan", LaserScan, self.driveStop_car_callback)
		self.timefound = 0
		""" initialize the box dimensions"""
		self.flag_box = ((0,0),(0,0))
		self.state = 0 
		""" 0: driving to wall, 1: sampling wall, 2: go to cone """
		self.leftVote = 0
		self.rightVote = 0
	

                """driving code"""
		self.cmd = AckermannDriveStamped()
		self.cmd.drive.speed = 0
		self.cmd.drive.steering_angle = 0
	
		"""get the camera data from the class Zed_converter in Zed"""
		self.camera_data = Zed_converter(False, save_image = False)
		self.lastUpdate = [0,time.time()]
		self.min_value=0
	def size_calc(self):
		""" calculate the x and y size of the box in pixels"""
		# use self.flag_box
		return abs(self.flag_box[0][0]-self.flag_box[1][0]) *  abs(self.flag_box[0][1]-self.flag_box[1][1])

	def driveForward(self,spd):
		#implement
		self.cmd.drive.steering_angle =  0
		self.cmd.drive.speed = spd
		self.pub.publish(self.cmd)

	def driveStop_car_callback(self,data):
		"""laser scan callback function"""
	
		#checks if the image is valid first
		while self.camera_data.cv_image is None:
			time.sleep(0.5)
			print("waiting for camera")

		self.flag_box = cd_color_segmentation(self.camera_data.cv_image)

		if self.state < 2:
			green,red = sift_det('oneway.jpg', self.camera_data.cv_image)
			if  max(red) == 0:
				pF.pf.scan_callback(data)

				if data.ranges[540] < 3:
				#	print "in the open, divide by 10, distance =",data.ranges[540]
					self.cmd.drive.steering_angle = 0 # pF.pf.finalVector[1]
				else:
				#	print "too close", data.ranges[540]
					self.cmd.drive.steering_angle = 0 #pF.pf.finalVector[1]
				self.cmd.drive.speed = pF.pf.finalVector[0]
				self.pub.publish(self.cmd)
			else:
				self.driveForward(0)
				#print self.camera_data.cv_image[red[1]-10][red[0]-20]
				#print self.camera_data.cv_image[red[1]][red[0] - 20]
				green = green[0]
				red =  red[0] - 10
				print 'red,green', str(red), str(green)
				if abs(red-green) < 120:
					if (green < red):
						self.leftVote += 5
						self.rightVote = 0
						print "left vote"
					else:
						self.leftVote = 0
						self.rightVote += 1
						print "right vote"
					if self.leftVote + self.rightVote >= 10:
					#	print "determining side"
						self.state = 2
						self.timefound = time.time()
		else:
			if self.size_calc() < 4:
				#print 'sizecalc',str(self.size_calc())
				if time.time() - self.timefound > 1.5:
					self.cmd.drive.speed = 1
					self.cmd.drive.steering_angle = 0
				else:
					self.cmd.drive.steering_angle = pi/2 if self.leftVote < self.rightVote else -pi/2
					self.cmd.drive.speed = -1
				self.pub.publish(self.cmd)
			else:
				
				self.drive(data)

		#applies the current filter to the image and returns a bounding box
		#finds the size of the box

		#self.size_calc()



	
	def drive(self,msg):
                """write driving commands here! You don't need to publish the drive command,
                that is being taken care of in the main() function"""
		if self.size_calc() == 0:
			self.cmd.drive.speed = 0
			self.cmd.drive.steering_angle = 0
		elif self.size_calc() <  10000:
			#print('contour area:' +str(self.size_calc()))
			#print('bounding boss: %s'%(str(self.flag_box)))
			self.cmd.drive.speed = 0.85 if self.size_calc() > 7000 else 1
			self.cmd.drive.steering_angle = 0
			err = (self.flag_box[0][0] + self.flag_box[1][0])/2 - 370
			#print "error bounds", self.flag_box[0][0],self.flag_box[1][0], err

			p_component =  (-1/400.0)* err
			
			#print(err-self.lastUpdate[0])
			#print(time.time()-self.lastUpdate[1])
			d_component = (err-self.lastUpdate[0])/float(time.time()-self.lastUpdate[1])
			d_component *= (1/200)
			
			self.lastUpdate = [err,time.time()]

			#print "pcomp", p_component,"dcomp",d_component
			self.cmd.drive.steering_angle = p_component - d_component
		
		else:
			#print('contour area low: %s'%((self.size_calc())))
			#print('countoubox: %s'%(str(self.flag_box)))
			print 'min-lidar-data',min(msg.ranges[360:720])
			err = (self.flag_box[0][0] + self.flag_box[1][0])/2 - 370
			if min(msg.ranges[400:650]) > 0.25:
				self.cmd.drive.speed = 0.25
				self.cmd.drive.steering_angle = 0
			else:
				if abs(err) < 90:
					self.cmd.drive.speed = -0.1
					self.cmd.drive.steering_angle = 0
				else:
					self.cmd.drive.speed = -0.1
					self.cmd.drive.steering_angle = 1/200.0 * err
		#print "Going at: %s / %s"%(self.cmd.drive.speed,self.cmd.drive.steering_angle)
		self.pub.publish(self.cmd)







def main():
        global AUTONOMOUS_MODE
	try:
		ic = driveStop()
		rate = rospy.Rate(100)
		while not rospy.is_shutdown():
			if AUTONOMOUS_MODE:
				ic.pub.publish(ic.cmd)
			
	except rospy.ROSInterruptException:
		exit()


if __name__ == "__main__":
	main()
