#!/usr/bin/env python
import math
import numpy as np
import rospy
from rospy.numpy_msg import numpy_msg
from sensor_msgs.msg import LaserScan
from ackermann_msgs.msg import AckermannDriveStamped
class WallFollower:
   # Import ROS parameters from the "params.yaml" file.
   # Access these variables in class functions with self:
   # i.e. self.CONSTANT
   SCAN_TOPIC = rospy.get_param("wall_follower/scan_topic")
   DRIVE_TOPIC = rospy.get_param("wall_follower/drive_topic")
   SIDE = rospy.get_param("wall_follower/side")
   VELOCITY = rospy.get_param("wall_follower/velocity")
   DESIRED_DISTANCE = rospy.get_param("wall_follower/desired_distance")
   global prev_dist
   prev_dist = 0
   global prev_angle
   prev_angle = 0

   def __init__(self):
       # Initialize your publishers and
       # subscribers
       self.data = None
       self.angle = 0
       self.cmd = AckermannDriveStamped()
       self.laser_sub = rospy.Subscriber(self.SCAN_TOPIC, LaserScan, self.scan, queue_size=1)
       self.drive_pub = rospy.Publisher(self.DRIVE_TOPIC, AckermannDriveStamped, queue_size=1)
       self.prev_dist = 0
   def scan(self, data):
   #stores the lidar data so you can work with it
       self.data = data
   #calls function that controls driving
       self.drive()

   def drive(self):
       """controls driving"""
       #Algorithm for driving
   #gets the angle required
       self.angle = self.find_wall()
   #sets speed and driving angle
       self.cmd.drive.steering_angle = self.angle
       #self.cmd.drive.steering_angle = 1
       
       #publishes the command
       self.drive_pub.publish(self.cmd)
   def find_wall(self):
   # if lidar data has not been received, do nothing
       if self.data == None:
            return     

   ## TO DO: Find Alg for Wall Following ##
       """Lidar data is now stored in self.data, which can be accessed
       using self.data.ranges (in simulation, returns an array).
       Lidar data at an index is the distance to the nearest detected object
       self.data.ranges[0] gives the leftmost lidar point
       self.data.ranges[100] gives the rightmost lidar point
       self.data.ranges[50] gives the forward lidar point
       """
       tempAngle = 0

       l = self.left()
       
       global prev_angle
       global prev_dist
       self.cmd.drive.speed = 0.5
       
       if self.data.ranges[l] < 0.5 and self.data.ranges[self.right()] < 0.5:
           self.cmd.drive.speed = 1
       if self.leftlarge() == 1 and self.forw() == 0:
           print "50 " ,self.data.ranges[50]
           tempAngle = 90
           prev_dist = self.data.ranges[75]
           if self.data.ranges[self.right()] < 0.5:
               print "ok"
               self.cmd.drive.speed = self.data.ranges[self.right()]
           prev_angle = 0
       elif self.data.ranges[self.right()] < 0.2:
           tempAngle = 1
           if prev_dist > self.data.ranges[self.right()] :
               tempAngle = 0
           prev_dist = self.data.ranges[self.right()]
       elif  self.data.ranges[self.left()] < 1 :
           print "0 " ,self.data.ranges[75]
           tempAngle = -10
       elif self.data.ranges[l] - self.data.ranges[l+1] * math.cos(2.7*6.28/360) > 1 or self.data.ranges[l] - self.data.ranges[l+1] * math.cos(2.7*6.28/360) < -1:
           print "01 ", self.data.ranges[l], " ", self.data.ranges[l+1]
           third = math.sqrt(self.data.ranges[l]*self.data.ranges[l] + self.data.ranges[l+1]*self.data.ranges[l+1] - 2*self.data.ranges[l]*self.data.ranges[l+1]*math.cos(2.7*6.28/360))
           ta = math.asin(math.sin(2.7*6.28/360)/third * self.data.ranges[l+1])*360/6.28
           print ta, " ", third, " ", math.cos(2.7*6.28/360)
           tempAngle = 90-ta - prev_angle
           prev_angle = tempAngle
       else:
           tempAngle = 0
           prev_dist = 0
       #for int i int range(100)
            
       print(tempAngle)
       return tempAngle
   
   def leftlarge(self):
       count = 0
       index = 0
       for i in range(25):
           if self.data.ranges[i+60] > 3:
               if index == 1: 
                    count+=1
               index = 1
           else:
               index = 0
               if count < 8:
                    count = 0
       if count > 8:
           return 1
       else:
           return 0
   
   def left(self):
       smallest = 1000
       index = 0
       for i in range(20):
           if self.data.ranges[i+60] < smallest:
               smallest = self.data.ranges[i]
               index = i+60
       return index

   def right(self):
       smallest = 1000
       index = 0
       for i in range(70):
           if self.data.ranges[i] < smallest:
               smallest = self.data.ranges[i]
               index = i
       return index

   def forw(self):
       for i in range(10):
           if self.data.ranges[i+30] > 4 :
                return 1
       return 0

if __name__ == "__main__":
   rospy.init_node('wall_follower')
   wall_follower = WallFollower()
   rospy.spin()
