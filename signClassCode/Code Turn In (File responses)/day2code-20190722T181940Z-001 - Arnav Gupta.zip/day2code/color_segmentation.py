import cv2
import imutils
import numpy as np
import pdb


def cd_color_segmentation(img, low_range, high_range, show_image=False):
    """
	Implement the cone detection using color segmentation algorithm
	    Input:
	    img: np.3darray; the input image with a cone to be detected
	Return:
	    bbox: ((x1, y1), (x2, y2)); the bounding box of the cone, unit in px
		    (x1, y1) is the bottom left of the bbox and (x2, y2) is the top right of the bbox
    """
    # convert from rgb to hsv color space (it might be BGR)
    new_img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    # define lower and upper bound of image values
    # TO DO!

    # create mask for image with overlapping values
    mask = cv2.inRange(new_img, low_range, high_range)

    # filter the image with bitwise and
    filtered = cv2.bitwise_and(new_img, new_img, mask=mask)

    # find the contours in the image
    _, contours, hierarchy = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

    x1, y1, x2, y2 = 0, 0, 0, 0
    if len(contours) != 0:
        # find contour with max area, which is most likely the cone
        # Solution note: max uses an anonymous function in this case, we can also use a loop...
        contours_max = max(contours, key=cv2.contourArea)

        # Find bounding box coordinates
        x1, y1, x2, y2 = cv2.boundingRect(contours_max)

        # Draw the bounding rectangle
        cv2.rectangle(img, (x1, y1), (x1 + x2, y1 + y2), (0, 255, 0), 2)

    if show_image:
        cv2.imshow("Color segmentation", img)
        key = cv2.waitKey()
        if key == 'q':
            cv2.destroyAllWindows()

    # Return bounding box
    return ((x1, y1), (x1 + x2, y1 + y2)), filtered


def signIdentify(img):
    # Python program to illustrate
    # multiscaling in template matching

    # Read the main image
    # [100:200, 200:472]
    im = img[120:180, 100:572]
    _, img_rgb = cd_color_segmentation(im, np.array([50, 0, 100]), np.array([200, 255, 200]))

    sign = img_rgb[_[0][1]:_[1][1], _[0][0]:_[1][0]]
    cv2.rectangle(img_rgb, _[0], _[1], (0, 255, 0))


    h, w, d= sign.shape

    sign_left = sign[:, 0:w/2]

    sign_right = sign[:, w/2:w]

    if np.count_nonzero(sign_left) > np.count_nonzero(sign_right):
        return 'left'#, im, sign
    else:
        return 'right'#, im, sign




    # Convert to grayscale
    img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)

    # Read the template
    template = cv2.imread(templateImg, 0)


    # Store width and heigth of template in w and h
    w, h = template.shape[::-1]
    found = None

    for scale in np.linspace(0.2, 1.0, 20)[::-1]:

        # resize the image according to the scale, and keep track
        # of the ratio of the resizing
        resized = imutils.resize(img_gray, width=int(img_gray.shape[1] * scale))
        r = img_gray.shape[1] / float(resized.shape[1])

        # if the resized image is smaller than the template, then break from the loop
        # detect edges in the resized, grayscale image and apply template matching to find the template in the image
        edged = cv2.Canny(resized, 50, 200)
        return [0], cv2.cvtColor(edged, cv2.COLOR_GRAY2RGB)
        print template.size, edged.size
        result = cv2.matchTemplate(edged, template, cv2.TM_CCOEFF)
        (_, maxVal, _, maxLoc) = cv2.minMaxLoc(result)
        # if we have found a new maximum correlation value, then update the found variable
        if found is None or maxVal > found[0]:
            if resized.shape[0] < h or resized.shape[1] < w:
                break
            found = (maxVal, maxLoc, r)

    # unpack the found varaible and compute the (x, y) coordinates
    # of the bounding box based on the resized ratio
    (_, maxLoc, r) = found
    (startX, startY) = (int(maxLoc[0] * r), int(maxLoc[1] * r))
    (endX, endY) = (int((maxLoc[0] + w) * r), int((maxLoc[1] + h) * r))

    # draw a bounding box around the detected result and display the image
    cv2.rectangle(img_rgb, (startX, startY), (endX, endY), (0, 0, 255), 2)
    # cv2.imshow("Image", img_rgb)
    # cv2.waitKey(0)
    box = ((startX, startY), (endX, endY))
    return box, img_rgb


# signIdentify('./images/leftTemplate.png', './images/onewayarrow.png')